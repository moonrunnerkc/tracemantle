"""Independently verify recorded skip identity/approval using standard library only."""
import hashlib,json,subprocess,sys,tomllib
from datetime import datetime,timezone
from pathlib import Path
results,seed=map(Path,sys.argv[1:])
rows=json.loads((results/'results.json').read_bytes())['rows']
revision=json.loads((seed/'seed.json').read_bytes())['trusted_revision']
raw=subprocess.check_output(['git','show',revision+':policy.toml'],cwd=seed)
policy=tomllib.loads(raw.decode())['tool']['tracemantle']['release']
checks={c['id']:c for c in policy['checks']}
canonical=lambda v:json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()
verified={'B':0,'C':0}
for row in rows:
 reference={c['id']:c for c in row['arms']['D']['checks']}
 for arm in verified:
  run=row['arms'][arm]
  for result in run['checks']:
   if not result['reused']:continue
   name=result['id']; check=checks[name]
   assert name in ('bundle-contract','upstream-tests') and not reference[name]['errors']
   current=run['gate']['identities'][name]
   original=json.loads((seed/'seed.json').read_bytes())['identities'][name]
   assert current==original
   scope=subprocess.check_output(['git','show',revision+':'+check['input_scope_path']],cwd=seed)
   assert hashlib.sha256(scope).hexdigest()==current['profile_sha256']==check['profile_sha256']
   assert json.loads(scope)['inputs']==check['inputs'] and not json.loads(scope)['unresolved']
   if arm=='C':
    record=json.loads(subprocess.check_output(['git','show',revision+':records/'+name+'.json'],cwd=seed))
    sha=hashlib.sha256(canonical(record)).hexdigest()
    selected=next(c for c in run['gate']['comparison']['checks'] if c['check_id']==name)
    assert sha==selected['evidence_sha256'] and sha in policy['trusted_evidence']
    assert all(current['inputs'][p][0]==h for p,h in record['inputs'].items())
    assert not run['gate']['manifest']['resource_errors']
    now=datetime.fromtimestamp((results/f'{row["case"]}-{row["repetition"]}'/arm/'decision.json').stat().st_mtime,timezone.utc)
    age=(now-datetime.fromisoformat(record['observed_at'])).total_seconds()
    assert -300<=age<=check['max_age_seconds']
   verified[arm]+=1
print(json.dumps({'verified_skips':verified,'incorrect_skips':0,'audit_uses_tracemantle_imports':False}))
