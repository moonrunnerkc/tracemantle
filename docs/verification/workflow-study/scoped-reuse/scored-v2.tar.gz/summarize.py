import json,sys,statistics
from collections import Counter
from pathlib import Path
source=Path(sys.argv[1]); data=json.loads(source.read_bytes())
summary={'implementation':data['implementation'],'trials':len(data['rows']),'experiment_seconds':data['seconds'],'arms':{},'cases':{},'reference_failed_trials':sum(r['verification']['reference_failed'] for r in data['rows']),'model_calls':0,'tokens':0,'model_cost_usd':0}
for arm in 'ABCD':
    runs=[r['arms'][arm] for r in data['rows']]
    checks=[c for run in runs for c in run['checks']]
    times=[run['invocation']['seconds'] for run in runs]
    summary['arms'][arm]={'required_checks':len(checks),'eligible_checks':2*len(runs),'reused':sum(c['reused'] for c in checks),'executed':sum(not c['reused'] for c in checks),'reused_by_check':dict(Counter(c['id'] for c in checks if c['reused'])),'mandatory_report_executions':sum(c['id']=='report' and not c['reused'] for c in checks),'subprocesses':sum(len(run['commands']) for run in runs),'scanner_executions':len(runs),'oracle_executions':len(runs),'cli_seconds':sum(times),'median_cli_seconds':statistics.median(times),'gate_seconds':sum(run['gate'].get('seconds',0) for run in runs),'per_trial_cli_seconds':times}
for r in data['rows']:
    case=summary['cases'].setdefault(r['case'],{'kind':'historical-source-replay' if r['case']=='control' or r['case'].startswith('history-') else 'controlled-change','repetitions':[]})
    case['repetitions'].append({'repetition':r['repetition'],'order':r['order'],'verification':r['verification'],'arms':{a:{'seconds':r['arms'][a]['invocation']['seconds'],'gate_seconds':r['arms'][a]['gate'].get('seconds',0),'reuse':[c['id'] for c in r['arms'][a]['checks'] if c['reused']],'check_failures':[c['id'] for c in r['arms'][a]['checks'] if c['errors']],'scanner_exit':r['arms'][a]['scan_exit']} for a in 'ABCD'}})
summary['additional_setup_recording_seconds']=data['seconds']-sum(a['cli_seconds'] for a in summary['arms'].values())
summary['B_minus_A_seconds']=summary['arms']['B']['cli_seconds']-summary['arms']['A']['cli_seconds']
summary['C_minus_A_seconds']=summary['arms']['C']['cli_seconds']-summary['arms']['A']['cli_seconds']
summary['C_minus_B_seconds']=summary['arms']['C']['cli_seconds']-summary['arms']['B']['cli_seconds']
summary['reference_outcome_disagreements']=sum(len(r['verification']['failures']) for r in data['rows'])
summary['validator_caught_trials']=sum(any(v['severity']=='error' for v in r['arms']['C']['gate']['validation']) for r in data['rows'])
summary['justified_skips']={a:sum(r['verification']['justified_skips'][a] for r in data['rows']) for a in 'BC'}
Path(sys.argv[2]).write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in {'cases','arms'}},indent=2))
print({a:{k:v for k,v in stats.items() if k!='per_trial_cli_seconds'} for a,stats in summary['arms'].items()})
